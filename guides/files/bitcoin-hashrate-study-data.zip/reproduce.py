"""Run with Python 3 and pandas. Reads only the adjacent frozen source CSV."""
from pathlib import Path
import json
import pandas as pd

HERE=Path(__file__).resolve().parent
d=pd.read_csv(HERE/'source_price_hashrate.csv',parse_dates=['date']).set_index('date').sort_index()
assert d.index.is_unique
assert (d.index.to_series().diff().dropna()==pd.Timedelta(days=1)).all()
d['hash_growth']=d.HashRate.pct_change(365)*100
d['same_return']=d.PriceUSD.pct_change(365)*100
d['next_return']=(d.PriceUSD.shift(-365)/d.PriceUSD-1)*100
d['above200']=d.PriceUSD>d.PriceUSD.rolling(200).mean()
d=d.dropna(subset=['hash_growth','same_return','next_return']).loc['2013-01-01':].copy()
cuts=d.hash_growth.quantile([.25,.5,.75]).tolist()
labels=['Slowest','Lower-middle','Upper-middle','Fastest']
d['group']=pd.cut(d.hash_growth,[-float('inf'),*cuts,float('inf')],labels=labels)
print('Starting dates',d.index.min().date(),'to',d.index.max().date(),'n=',len(d))
print('Full-sample growth cutoffs',cuts)
print('Same-year Pearson correlation',d.hash_growth.corr(d.same_return))
print('Next-year Pearson correlation',d.hash_growth.corr(d.next_return))
actual=d.groupby('group',observed=True).next_return.agg(['size','median'])
print('\nFour groups\n',actual)
print('\nPrice-trend splits\n',d.groupby(['group','above200'],observed=True).next_return.agg(['size','median']))
print('\nStarting years\n',pd.crosstab(d.index.year,d.group))
expected=pd.read_csv(HERE/'quartiles.csv').set_index('group')
for label in labels:
    assert int(actual.loc[label,'size'])==int(expected.loc[label,'n'])
    assert abs(actual.loc[label,'median']-expected.loc[label,'median'])<1e-8
assert len(d)==4526
print('\nPublished group counts and medians reproduced.')
