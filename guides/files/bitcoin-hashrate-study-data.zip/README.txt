THE BITCOIN HASHRATE STUDY
Edition October 27, 2026. Calculations by Bitcoin Daily.

This package contains public-data research, not proprietary cycle-model internals.

source_price_hashrate.csv
  Frozen Coin Metrics daily HashRate (TH/s) and PriceUSD inputs.
  July 18, 2010 through May 23, 2026.
observations.csv
  All 4,526 eligible starting dates, January 1, 2013 to May 23, 2025.
quartiles.csv
  Counts and median following-365-day BTC returns, by full-sample growth group.
regimes.csv
  The same groups split by starting price above vs at/below its 200-day average.
start_year_counts.csv
  Distribution of each growth group across starting years.
reproduce.py
  Recalculates the tables offline. Requires Python 3 and pandas.
  Run: python reproduce.py

METHOD
Past growth = 100 * (HashRate[t] / HashRate[t-365] - 1).
Next return = 100 * (PriceUSD[t+365] / PriceUSD[t] - 1).
The 200-day simple moving average includes the starting day's price.
The source series has no duplicate or missing usable daily dates.
The full-sample quartile cutoffs use pandas' default linear quantile interpolation.
The lower edge of each band is exclusive, except the first band.
Medians are simple BTC/USD price returns; no execution, fees or trading strategy is modeled.

LIMITATIONS
Windows overlap heavily. Counts are daily observations, not independent trades or cycles.
Quartile cutoffs use the entire sample, including hindsight. No out-of-sample result is claimed.
The raw daily hash rate is an estimate and can be noisy.
Correlations do not establish causal direction or rule out nonlinear relationships.
The fastest-growth group contains only 2013-2018 start dates.
This frozen edition is not a live October 27 market signal.

PRIMARY SOURCES
https://github.com/coinmetrics/data/blob/master/csv/btc.csv
https://gitbook-docs.coinmetrics.io/network-data/network-data-overview/mining/hash-rate
https://www.blockchain.com/explorer/charts/hash-rate

Fresh upstream downloads may extend or revise the data and change the results.
Source metrics are attributed to Coin Metrics. Transformations and presentation by Bitcoin Daily.
Educational research, not personalized financial advice.
